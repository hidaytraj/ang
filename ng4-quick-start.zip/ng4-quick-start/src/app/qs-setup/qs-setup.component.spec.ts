import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QsSetupComponent } from './qs-setup.component';

describe('QsSetupComponent', () => {
  let component: QsSetupComponent;
  let fixture: ComponentFixture<QsSetupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QsSetupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QsSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

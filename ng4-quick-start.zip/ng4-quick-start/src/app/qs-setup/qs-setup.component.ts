import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qs-setup',
  templateUrl: './qs-setup.component.html',
  styleUrls: ['./qs-setup.component.scss']
})
export class QsSetupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  constructor() {
    var winWidth = window.innerWidth;
    var winHeight = window.innerHeight;
  }
  
}

import { Component } from '@angular/core';

@Component({
    selector: 'footer-section',
    templateUrl: './footer.component.html'
})

export class FooterComponent {
    currentYear:number;
    
    constructor() {
        let date, year;
        date = new Date();
        year = date.getFullYear();
        this.currentYear = year;
    }
}
import { Component } from '@angular/core';

@Component({
    selector: 'header-section',
    templateUrl: './header.component.html'
})

export class HeaderComponent {

}
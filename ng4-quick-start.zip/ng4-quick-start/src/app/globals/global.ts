export const GLOBAL = {
    title : "ng4 Quick Start"
}
import { Component, OnInit } from '@angular/core';

import { GLOBAL } from '../globals/global';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  title:string = GLOBAL.title;
  constructor() { }

  ngOnInit() {
  }

}

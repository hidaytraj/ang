import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qs-font-awesome',
  templateUrl: './qs-font-awesome.component.html',
  styleUrls: ['./qs-font-awesome.component.scss']
})
export class QsFontAwesomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QsFontAwesomeComponent } from './qs-font-awesome.component';

describe('QsFontAwesomeComponent', () => {
  let component: QsFontAwesomeComponent;
  let fixture: ComponentFixture<QsFontAwesomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QsFontAwesomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QsFontAwesomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

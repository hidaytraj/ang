import { BrowserModule } from '@angular/platform-browser';
// External Modules
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AngularFontAwesomeModule } from 'angular-font-awesome/angular-font-awesome';
import { RouterModule } from '@angular/router';

// Componets
import { AppComponent } from './app.component';
import { HeaderComponent } from './globals/header.component';
import { FooterComponent } from './globals/footer.component';
import { QsBootstrapComponent } from './qs-bootstrap/qs-bootstrap.component';
import { QsFontAwesomeComponent } from './qs-font-awesome/qs-font-awesome.component';
import { QsSetupComponent } from './qs-setup/qs-setup.component';
import { DashboardComponent } from './dashboard/dashboard.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    QsBootstrapComponent,
    QsFontAwesomeComponent,
    QsSetupComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    NgbModule.forRoot(),
    AngularFontAwesomeModule,
    RouterModule.forRoot([
      {
        path: 'dashboard',
        component: DashboardComponent
      },

      {
        path: 'bootstrap4',
        component: QsBootstrapComponent
      },

      {
        path: 'fontawesome',
        component: QsFontAwesomeComponent
      },

      {
        path: 'setup',
        component: QsSetupComponent
      },

    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

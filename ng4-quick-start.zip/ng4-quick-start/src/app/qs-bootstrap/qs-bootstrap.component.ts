import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qs-bootstrap',
  templateUrl: './qs-bootstrap.component.html',
  styleUrls: ['./qs-bootstrap.component.scss']
})
export class QsBootstrapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
